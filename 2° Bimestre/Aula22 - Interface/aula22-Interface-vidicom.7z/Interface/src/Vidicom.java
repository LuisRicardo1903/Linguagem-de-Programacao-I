public class Vidicom implements Sensor, Atuador {
    
    public static void main(String[] args) {
        Vidicom vidicom = new Vidicom();
        while (true) {
            if (vidicom.getValor() <= 19) {
                vidicom.desligar();
            }
            else {
                vidicom.ligar();
            }
        }
        
   
}

    @Override
    public int getValor() {
        int valor = (int) (Math.random() * 20 ) + 1;
        return valor;
    }

    @Override
    public void ligar() {
        System.out.println("Sirene LIGADA");    
    }

    @Override
    public void desligar() {
        System.out.println("Sirene DESLIGADA");
    }
    
}
