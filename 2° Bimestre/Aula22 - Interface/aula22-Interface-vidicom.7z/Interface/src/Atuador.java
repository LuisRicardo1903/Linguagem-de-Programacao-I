public interface Atuador {
    
    public void ligar();
    public void desligar();
    
}
