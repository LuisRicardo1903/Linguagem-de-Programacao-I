public interface Sensor {
    
    public int getValor();
    
}
