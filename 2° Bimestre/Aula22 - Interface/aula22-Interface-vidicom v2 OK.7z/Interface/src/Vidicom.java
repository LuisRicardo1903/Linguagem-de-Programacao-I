public class Vidicom implements Sensor, Atuador {
    
    public static void main(String[] args) {
        Vidicom vidicom = new Vidicom();    
        while (true) {
            int valor = vidicom.getValor();
            if (valor<= 100) {
                vidicom.desligar();
                System.out.println(valor);
            }
            else {
                vidicom.ligar();
                System.out.println(valor);
                break;
            }
        }
        
   
}

    @Override
    public int getValor() {
        int valor = (int) (Math.random() * 100 ) + 1;
        return valor;
    }

    @Override
    public void ligar() {
        System.out.println("Sirene LIGADA");    
    }

    @Override
    public void desligar() {
        System.out.println("Sirene DESLIGADA");
    }
    
}
