
import javax.swing.JOptionPane;

public class Menu {
    public int opcao;
    
    public void exibir(){
        opcao =Integer.parseInt(JOptionPane.showInputDialog("Menu\n" + "1-Inserir contato\n" + "2-Consultar contato\n" + "3-Inserir compromisso\n" + "4-Consultar compromisso\n" + "5-Sair"));
    }
}
