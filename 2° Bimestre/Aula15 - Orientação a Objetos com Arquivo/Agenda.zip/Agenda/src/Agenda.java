
import javax.swing.JOptionPane;

public class Agenda {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.exibir();
        switch(menu.opcao){
            case 1: {
                Contatos contatos = new Contatos ();
                contatos.nome = JOptionPane.showInputDialog("Digite o nome:");
                contatos.telefone = JOptionPane.showInputDialog("Digite o nº do telefone:");
                contatos.inserir();
                break;
            }
            case 2: {
                Contatos contatos = new Contatos ();
                String nome = JOptionPane.showInputDialog("Digite o nome:");
                String resposta = contatos.consultar(nome);
                System.out.println(resposta);
                break;
            }
        }
    }
    
}
