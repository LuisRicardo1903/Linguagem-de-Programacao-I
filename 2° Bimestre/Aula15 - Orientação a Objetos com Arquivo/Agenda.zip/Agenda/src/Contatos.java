import java.io.*;

public class Contatos {
    public String nome;
    public String telefone;
    
    public void inserir (){
        System.out.println("Nome:" + nome + "\n" + "Telefone:" + telefone);
        BufferedWriter bw;
        try {
            bw = new BufferedWriter (new FileWriter(nome+".txt"));
            bw.write(nome);
            bw.newLine();
            bw.write(telefone);
            bw.newLine();
            bw.write("oi");
            bw.close();
        } catch(Exception e){
          
        }
    }
    
    public String consultar(String nome){
        String linha, conteudo = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(nome+".txt"));
            while ((linha=br.readLine()) != null){
                conteudo= conteudo +linha+"\n";
            }
            br.close();
        }catch(Exception e){
           
        }
    return conteudo;        
    }
}
